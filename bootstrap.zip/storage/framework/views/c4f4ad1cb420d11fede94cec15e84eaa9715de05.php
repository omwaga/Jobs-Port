<?php $__env->startSection('content'); ?>
<div class="container" style=" padding-top: 7rem;">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <h5 style="color:#0B0B3B; padding-top:1em;" align="center"><?php echo e(__('Hello!')); ?></h5>
                <h5 style="color:#0B0B3B;" align="center"><?php echo e(__('Welcome Back')); ?></h5>
                <p align="center"><?php echo e(__('You are just a step away from your dream job.')); ?></p>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email address')); ?></label>

                            <div class="col-md-7">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-7">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary"  style="border-radius: 0px;">
                                    <?php echo e(__('Login')); ?>

                                </button>
                                <a class="btn btn-danger text-white" href="<?php echo e(route('google.login')); ?>"  style="border-radius: 0px;"><i class="fab fa-google-plus-g"></i> Login with Google</a>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
		    <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="<?php echo e(asset('Images/find-better.svg')); ?>" alt="First slide" style="width:300px; height:300px">
  <h5 align="center">Find Better</h5>
  <p align="center">Find Better jobs that match your skills from top Employers in East Africa.</p>
  </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo e(asset('Images/quick-apply.svg')); ?>" alt="Second slide" style="width:300px; height:300px">
  <h5 align="center">Apply Quickly</h5>
  <p align="center">Save time and effort with The NetworkedPros Quick Apply.</p>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo e(asset('Images/job-alerts.svg')); ?>" alt="Third slide" style="width:300px; height:300px">
  <h5 align="center">Job Alerts</h5>
  <p align="center">Get real time alerts for hot new jobs.</p>
   </div>
  </div>
</div>
		</div>
	</div>
	        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/auth/login.blade.php ENDPATH**/ ?>