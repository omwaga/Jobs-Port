<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Countrylist extends Model
{
    //
    protected $fillable = [
        'country',
    ];
}
