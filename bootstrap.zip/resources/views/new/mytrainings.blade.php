@extends('layouts.jobs')
@section('content')
 <div class="container-fluid">
    	 <div class="card card-header"><h5 style="font-family: 'Roboto', sans-serif;">My Trainings</h5></div>
	      <hr>
     <div class="card card-body">
     <div class="table-responsive">
     <table class="table table-striped table-bordered" id="apply-data">
                                                                           <thead class=thead>
                                                                               <tr>
                                                                                   <th>#</th>
                                                                                   <th>Title</th>
                                                                                    <th>Description </th>
                                                                                   <th>Duration </th>
                                                                                   <th>Start date</th>
                                                                               
                                                                               </tr>
                                                                           </thead>
                                                                       <tbody>
                                                                           
                                                                           <tr>
                                                                           <td>#</td>
                                                                           <td>#</td>
                                                                           <td>#</td>
                                                                           <td>#</td>
                                                                           <td>#</td>
                                                                           </tr>
                                                                         
                                                                       </tbody>
                                                                        
                                                                    
                                                                       </table>
 </div>
 </div>
 </div>
@endsection