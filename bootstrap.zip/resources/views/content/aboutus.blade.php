@extends('layouts.app')
@section('content')
<div class="container" style="border-right: solid 10px red;">
<div class="card-header bg-info text-white"><h1 class="text-center b" style="font-family: 'Sniglet', cursive;">What is The Networked Pros</h1></div>
<hr style="border:solid 0.5px black;">
<div class="card card-body">
<p class="text-center">Thenetworkedpros is afican leading job website that provides a platform for individuals to 
    search and apply for jobs in their areas of interest. The platform connects jobseekers to their dream 
    employers.Additionally, we provide plaforms for various groups and individuals in order to 
    automate their services and provide easier access to their daily activities.
    
</p>
<p><h3 class="text-center">We connect the following groups</h3></p>
<ul>
        <li class="nav-item text-center h4"><a class=" text-center text-danger" href="#">Jobseekers</a></li>
    <li class="nav-item text-center h4"><a class=" text-center text-danger" href="#">Employers</a></li>
    <li class="nav-item text-center h4"><a class=" text-center text-danger" href="#">Experts</a></li>
    <li class="nav-item text-center h4"><a class=" text-center text-danger" href="#">Professional Bodies</a></li>
</ul>
<p>
    We have provided a platform for opportunities in Eastern Africa and the rest of the world to both jobseekers and
    the employers. Do you want to get a job instantly? Apply with us and ghet access to a million jobs all over
    te world.
</p>
</div>
</div>
@endsection