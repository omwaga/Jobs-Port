@extends('layouts.app')
@section('content')
    <div class="jumbotron jumbotron-fluid" style=" background-image: url('/Images/back/eve.jpg');background-repeat: no-repeat ;background-size: cover;background-attachment: fixed;
width: 100%;">
       <div class="container">
        <p style="font-weight: 400px;font-family: 'PT Sans Narrow', sans-serif; color: #fff"><h1 class="" style="font-weight: 500px;font-family: 'PT Sans Narrow', sans-serif; color: #fff">
        The best Technology for events on the planet.</h1></p>
        <p><h3 class="text-white" style="font-weight: 500px;font-family: 'PT Sans Narrow', sans-serif;">
        We The networked pros  bring people together through <br>
        multiple events. Simply create and post an event with us and<br>
    we shall connect you to million potential users.
</h3></p>
<br>

        </div>
        <div class="container">
        <div class="row" style="padding-top: 4%;">
            <div class="col-sm-4">
              
                
            </div>
            <div class="col-sm-4">
                    <p class="text-white"><a class="btn btn-danger btn-lg btn-block">Post an Event with us</a></p>
              
            </div>
            <div class="col-sm-4">
               

            </div>
        </div>
        </div>
    </div>
    <div class="container">
        <p><h1 class="text-center" style="color: #054963;">The real world is calling.</h1><h4 class="text-center">
                Join us to meet people, try something new. This is what you get with us</h4></p>
    </div>
    <div class="container-fluid" style="background-color: #0F1C47;">
        <div class="container">
            <div class="row">
            <div class="col-sm-4">
                <div class="card card-body text-white" style="background-color: #0F1C47;" >
                    <p class="text-center"><i class="fa fa-users fa-4x"></i>
                        <h4 class="text-center">Networking</h4>
                    <h6>We connect you to top most companies and top
                        professionals all over the world.Get a chance 
                    to showcase yourself in these events. Let them see who you are.</h6></p>  
                </div>
            </div>
            <div class="col-sm-4">
                    <div class="card card-body text-white" style="background-color: #0F1C47;" >
                            <p class="text-center"><i class="fa fa-sign-language fa-4x"></i>
                                <h4 class="text-center">Exposure</h4>
                            <h6>Let top companies/professionals see what you got.
                                Get a chance to be exposed to top level
                            events organized by top level companies all over the world.</h6></p>
                            <p></p>
                        </div>
            </div>
            <div class="col-sm-4">
                    <div class="card card-body text-white" style="background-color: #0F1C47;" >
                            <p class="text-center"><i class="fa fa-book fa-4x"></i>
                                <h4 class="text-center">Learning</h4>
                            <h6>These events have professionals with vast
                                experience who are ready to give you insight on
                            matters relating your area of interest.</h6></p>
                            <p></p>
                        </div>
            </div>
            </div>
        </div>
    </div>
    <div class="container">
        <p><h1 class="text-center" style="color: #054963;">Latest Events</h1></p>
        <div class="row">
            <div class="col-sm-4">
                <div class="card card-body">
                    <p><h5 class="text-primary text-center">Event 1 heading</h5></p>
                    <p>Event Information</p>
                    <p class=""><a class="btn btn-primary text-white float-right">Read More <i class="fa fa-angle-double-right"></i></a></p>
                </div>
            </div>
            <div class="col-sm-4">
                    <div class="card card-body">
                            <p><h5 class="text-primary text-center">Event 2 heading</h5></p>
                            <p>Event Information</p>
                            <p class=""><a class="btn btn-primary text-white float-right">Read More <i class="fa fa-angle-double-right"></i></a></p>
                        </div>
            </div>
            <div class="col-sm-4">
                    <div class="card card-body">
                            <p><h5 class="text-primary text-center">Event 3 heading</h5></p>
                            <p>Event Information</p>
                            <p class=""><a class="btn btn-primary text-white float-right">Read More <i class="fa fa-angle-double-right"></i></a></p>
                        </div>
            </div>
        </div>
    </div>
@endsection