<?php $__env->startSection('content'); ?>
<!--<br>-->
<section class="section section-top section-full">
<div class="jumbotron jumbotron-fluid" style="background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0)), url(<?php echo e(asset('Images/cv2.jpg')); ?>)">
  <div class="container">
  <div class="row">
      <div class="col-md-8" style=" padding-top: 5rem;">
      <h2 class=" text-white text-center">Get the best job vacancies <br> & careers from NGO's, Government, & Private Institutions.</h2>
      <h4 class="text-white text-center">Browse for latest jobs and land your dream job.</h4>
  </div>
  <div class="col-md-4" align="center">
      <div class="">
        <h5 class="text-white">Free Job Alerts</h5>
        <p class="text-center text-white">Get an Email on jobs matching your criteria </p>
        <p class="text-white">No Registration Required</p>
        <button class="btn text-white" data-toggle="modal" data-title="" data-caption="" data-target="#alert" style="background-color:#070A53;">Create Job Alert</button>
        </div>
    </div>
  </div>
  </div><br>
  <div class="container">
                <form method="get" action="<?php echo e(route('homesearch')); ?>">
              <?php echo csrf_field(); ?>
        <div class="col-lg-12">
         <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12 p-0">
               <select name="industry" class="form-control search-slt">
                  <option>Job functions</option>
                  <?php $__currentLoopData = $industry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($inda->id); ?>"><?php echo e($inda->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

          </div>
          <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                            <select name="function" class="form-control search-slt">
                  <option>Select category</option>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($jobt->id); ?>"><?php echo e($jobt->jobcategories); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 p-0">
                          <select name="country" class="form-control search-slt">
                       <option value="">Select Country</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select> 
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 p-0">
                          <select name="state" class="form-control search-slt">
                       <option>State/Region</option>
              </select> 
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 p-0">
             <button type="submit" class="btn btn-danger wrn-btn">Search</button>
          </div>
          </div>
          </div>
                    </form>
  </div>
</div>
</section>
<div class="container" >
  <div class="row" align="center">
            <div class="col-md-12" align="center">
                <div class="process-box process-left">
                    <div class="row">
                        <!-- <div class="col-md-5">
                            <div class="process-step">
                                <p class="m-0 p-0">Step</p>
                                <h2 class="m-0 p-0">01</h2>
                            </div>
                        </div> -->
                        <div class="col-md-10" align="center">
                            <h5>Create a Professional Resume and Cover Letter</h5>
                            <p>Use professional field-tested resume templates that follow the exact ‘resume rules’ employers look for. Easy to use & done within minutes - try now for free! <br><a class="btn text-white" style="background-color:#0B0B3B;" href="<?php echo e(route('customizeresume')); ?>">Get Started</a></p>
                        </div>
                    </div>
                    <!--<div class="process-line-l"></div>-->
                </div>
            </div>
        </div>
</div><br>
<div class="container bg-light">
    <div class="row justify-content-center">
     	    <h5 style="color:#0B0B3B;"><strong>Search Best Talent with The NetworkedPro's Resume Database Access</strong></h5>
			 
			    <div class="col-lg-6 col-xs-12 text-center">
					<div class="box">
						<div class="box-title">
							<h5 style="color:#0B0B3B;">Hiring is Simpler, Smarter &
Faster with The NetworkedPros</h5>
						</div>
    <p class="lead text-center">
    Get in touch with our team <br>
    info@thenetworkedpros.com<br>
    To get started with our fast and easy job posting services.
    </p>  
					 </div>
				</div>	 
				
				 <div class="col-lg-6 col-xs-12  text-center">
					<div class="box">
						<div class="box-title">
							<h5 style="color:#0B0B3B;"> Find Better Candidates, Faster.For employers who need great people.</h5>
							<h6>Reach out to millions of jobseekers and hire quickly with our fast and easy job posting services. </h6>
							<div class="row">
							    <div class="col-md-6">
							       <p><i class="fa fa-clock text-info" aria-hidden="true"></i> 2 Minutes to Post</p>
							       <p><i class="fa fa-users text-info" aria-hidden="true"></i> Attract Audience</p>
							       <p><i class="fa fa-volume-control-phone text-info" aria-hidden="true"></i> Contact Directly</p>
							    
						<div class="box-btn">
						    <a class="btn text-white btn-sm" style="background-color:#0B0B3B;" href="<?php echo e(route('leads')); ?>">Know More</a>
						</div>
							    </div>
							    <div class="col-md-6">
							       <p><i class="fa fa-flag text-info" aria-hidden="true"></i> Unlimited Applies</p>
							       <p><i class="fa fa-bullseye text-info" aria-hidden="true"></i> 30 days Job Visibility</p>
							        <p><i class="fa fa-pied-piper text-info" aria-hidden="true"></i> Manage your Applicants</p>
							    
						<div class="box-btn">
						    <a class="btn btn-danger text-white btn-sm" href="<?php echo e(route('hirre')); ?>">Register</a>
						</div>
							    </div>
							</div>
						</div>
					 </div>
				</div>
		</div>
    
</div>
<br>
<br>
<div class="container">
        <div class="col-md-12" align="center">
    <h4 style="margin-top:2%; text-center"><b>Latest Jobs</b></h4>
    
      <div class="row">
    		  	<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		  	<div class="col-md-4">
    		  	<div class="card card-body border-light shadow-lg p-3 mb-5 bg-white rounded">
    		  	    <p><a href="/jobview/<?php echo e($job->id); ?>" class="font-weight-bold" style="color:#0B0B3B;">
    		  	   <?php echo $job->jobtitle; ?>

    		  	   </a></p>
    		  	    <p><?php echo e($job->jobtype); ?> | Expiry Date: <?php echo e($job->expirydate); ?> | Salary Ksh <?php echo e($job->salary); ?></p>
    		  	   <!-- <?php if( $job->expirydate > Carbon\Carbon::now() ): ?>
    		  	   <p class="text-danger">Job expires after <span class="badge badge-primary"><?php echo e(Carbon\Carbon::parse($job->expirydate)->diffInDays(Carbon\Carbon::now())); ?> </span> days </p>
    		  	   <?php else: ?>
    		  	   <p class="text-danger">Job has expired</p>
    		  	   <?php endif; ?> -->
    		  	</div>
    		  	<br>
    		  	</div>
      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      	<div class="col-md-12" align="center">
      	  <?php echo e($jobs->links()); ?>

      	</div><br>
    	</div>
        </div>
    	    <div class="col-md-12" align="center">
    	    <a href="<?php echo e(route('alljobs')); ?>" class="btn text-white" style="background-color:#070A53;">Browse the <?php echo e($alljobs->count()); ?> Jobs</a>
    	    </div>
</div>

        <?php echo $__env->make('new.create-alertsmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <script type="text/javascript">
    jQuery(document).ready(function ()
    {
            jQuery('select[name="country"]').on('change',function(){
               var countryID = jQuery(this).val();
               if(countryID)
               {
                  jQuery.ajax({
                     url : 'dropdownlist/getstates/' +countryID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="state"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="state"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="state"]').empty();
               }
            });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/home.blade.php ENDPATH**/ ?>