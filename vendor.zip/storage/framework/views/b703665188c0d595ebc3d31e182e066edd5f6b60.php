<?php $__env->startSection('title'); ?>
Latest Job Vacancies and Training Courses in East Africa(Kenya, Uganda, Rwanda, Tanzania and Burundi)
<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
Latest Job vacancies and Training courses in Kenya, Uganda, Tanzania, Rwanda and Burundi.
<?php $__env->startSection('keywords'); ?>
latest jobs in kenya,latest jobs in kenya 2019, latest jobs in kenya today,job vacancies in kenya,job vacancies in kenya today,latest job vacancies in kenya
job vacancies in kenya 2019,
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- HERO
    ================================================== -->
    <section class="section section-top section-full">

        <!-- Cover -->
        <div class="jumbotron jumbotron-fluid" style="background-color:#2B3856; background-image:url('<?php echo e(asset('Images/corporate.jpg')); ?>');">

        <!-- Overlay -->
        <div class="bg-overlay"></div>
        <!-- Content -->
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-12 col-lg-12">
                    <div class="banner-content">
                        <!-- Preheading -->
                        <p class="text-white text-uppercase text-center text-xs">
                          <span>The NetworkedPros</span>
                        </p>

                        <!-- Heading -->
                        <h1 class="text-white text-center mb-4 display-4 font-weight-bold">
                            Land the right jobs<br>& vacancies in kenya
                        </h1>

                        <!-- Subheading -->
                        <p class="lead text-white text-center mb-5">
                            Search for latest Jobs in Kenya.
                        </p>
    <div class="container" style="margin-bottom:1%;">
                <form method="get" action="<?php echo e(route('homesearch')); ?>">
              <?php echo csrf_field(); ?>
      <div class="row">
          <div class="col-lg-3">
               <select name="industry" class="form-control" style="border-radius:0px;">
                  <option>Job functions</option>
                  <?php $__currentLoopData = $industry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($inda->id); ?>"><?php echo e($inda->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

          </div>
          <div class="col-lg-3">
                            <select name="function" class="form-control" style="border-radius:0px;">
                  <option>Select category</option>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($jobt->id); ?>"><?php echo e($jobt->jobcategories); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="col-lg-3">
                          <select name="location" class="form-control" style="border-radius:0px;">
                       <option>select location</option>
                      <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($town->id); ?>"><?php echo e($town->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select> 
          </div>
          <div class="col-lg-3">
             <button type="submit" class="btn btn-danger text-white btn-block" style="border-radius:0px;"><i class="fas fa-search"></i> search</button>
          </div>
                    </form>
      </div>
  </div>
                    </div>
                </div>
            </div>
            <!-- / .row -->
        </div>
        <!-- / .container -->
    </section>
    
<br>
<div class="container">
  <ul class="nav nav-tabs tabs-left bg-light" role="tablist" style="display:block;float:left;">
    <li class="nav-item " style="border-bottom: 8px solid #fff;">
      <a class="nav-link active text-primary" data-toggle="tab" href="#menu1" style="color:#0B0B3B;"><i class="fa fa-list-alt fa-x text-danger" aria-hidden="true"></i> </i> Jobs by Category</a>
    </li>
    <br>
    <li class="nav-item"  style="border-bottom: 8px solid #fff;">
      <a class="nav-link text-primary" data-toggle="tab" href="#menu2" style="color:#0B0B3B;"><i class="fa fa-map-marker fa-x text-danger" aria-hidden="true"></i> Jobs by location</a>
    </li>
    <br>
    <li class="nav-item" style="border-bottom: 8px solid #fff;">
      <a class="nav-link text-primary" data-toggle="tab" href="#home" style="color:#0B0B3B;"><i class="fa fa-clock-o fa-x text-danger" aria-hidden="true"></i> View Latest Jobs</a>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane fade"><br>
    	<div class="row">
    		  	<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<div class="col-md-6">
      	    <a href="/jobview/<?php echo e($job->id); ?>" class="list-group-item nav-link" style="color:#0B0B3B;border-top:solid 0.5px #000;border-left:0px;border-right:0px;border-bottom:0px;"><i class="fas fa-caret-right"></i> <?php echo e($job->jobtitle); ?> |
  Job type: <?php echo e($job->jobtype); ?></a> 
      	</div>
      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>
    </div>
    <div id="menu1" class="container tab-pane active"><br>
     <div class="row">
         
     	    		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	    		<?php if($category->jobs->count() > 0): ?>
    		<div class="col-md-4">
    		    <a class="list-group-item" href="/Industries/<?php echo e($category->jobcategories); ?>" style="color:#0B0B3B;border-top:dotted 0.5px #000;border-left:0px;border-right:0px;"><i class="fas fa-caret-right"></i> <?php echo e($category->jobcategories); ?> <span class="badge badge-primary float-right"><?php echo e($category->jobs->count()); ?></span></a>
    		</div>
    		<?php endif; ?>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		
     </div>
    </div>
    <div id="menu2" class="container tab-pane fade"><br>
      <div class="row">
              <?php if(count($towns) > 0): ?>
          <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-3">
              <a href="/Location/<?php echo e($town->name); ?>" class="list-group-item nav-link" style="color:#0B0B3B;border-top:dotted 0.5px #000;border-left:0px;border-right:0px;"><i class="fas fa-caret-right"></i> <?php echo e($town->name); ?><span class="badge badge-primary float-right"><?php echo e($town->jobposts->count()); ?></span></a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?> 
      </div>

    </div>
  </div>
  <div class="container" style="height:60px;">
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- displayadd -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9415122333094581"
     data-ad-slot="6054451855"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
  <div class="container-fluid column card card-body border-light d-flex justify-content-center">
  <h3 class="text-center"><b>Top Jobs</b></h3><br>
  <div class="row">
    		  	<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		  	<div class="col-md-4">
    		  	<div class="card card-body bg-light">
    		  	    <p><a href="/jobview/<?php echo e($job->id); ?>" class="text-danger font-weight-bold">
    		  	   <?php echo $job->jobtitle; ?>

    		  	   </a></p>
    		  	    <p><?php echo e($job->jobtype); ?> | Expiry Date: <?php echo e($job->expirydate); ?> | Salary Ksh <?php echo e($job->salary); ?></p>
    		  	   <?php if( $job->expirydate > Carbon\Carbon::now() ): ?>
    		  	   <p class="text-danger">Job expires after <span class="badge badge-primary"><?php echo e(Carbon\Carbon::parse($job->expirydate)->diffInDays(Carbon\Carbon::now())); ?> </span> days </p>
    		  	   <?php else: ?>
    		  	   <p class="text-danger">Job has expired</p>
    		  	   <?php endif; ?>
    		  	</div>
    		  	<br>
    		  	</div>
<!--      	<div class="col-md-4 shadow-lg p-3 mb-5 bg-white rounded">-->
<!--      	    <div class col-md-12>-->
<!--      	        <a href="/jobview/<?php echo e($job->id); ?>" class="text-danger"><h5 > <?php echo e($job->jobtitle); ?></h5></a>-->
<!--    <ul class="list-group list-group-flush">-->
<!--  <li class="list-group-item">-->
<!--  <?php echo e($job->jobtype); ?> | Expiry Date: <?php echo e($job->expirydate); ?> | Salary Ksh <?php echo e($job->salary); ?>-->
<!--  </li>-->
<!--</ul>-->
<!--</div>-->
<!--      	</div>-->
      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/job.blade.php ENDPATH**/ ?>