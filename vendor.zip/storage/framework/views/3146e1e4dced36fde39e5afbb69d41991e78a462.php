<?php $__env->startSection('content'); ?>

        <!--body wrapper start-->
        <div class="wrapper">
              
              <!--Start Page Title-->
               <div class="page-title-box">
                    <h4 class="page-title">Resume Samples Domain</h4>
                    <ol class="breadcrumb">
                        <li>
                            <a href="/admin-dashboard">Dashboard</a>
                        </li>
                        <li class="active">
                            Resume Samples Domain
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                 </div>
                  <!--End Page Title-->          
           
                  <!--Start row-->
                    <div class="row">
                       <div class="col-md-12">
                       
                        
                       <div class="row">
                            <?php if($domains->count() > 0): ?>
                            
                             <div class="col-md-12">
                <div class="white-box">
                  <div class="row"> 
                           <div class="col-md-6">
                       <h2 class="header-title">Resume Domains</h2>
                       </div>
                       <div class="col-md-6">
                    <button class="btn btn-info pull-right" data-toggle="modal" data-target="#modal-large" type="button">New Category</button>
                    </div>
                    </div>
                    <div class="table-responsive">

                                    <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <table class="table table-hover">
                                <thead>
                                  <tr>
                                    <th>#</th>
                                    <th>Domain Name</th>
                                    <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                    <?php $column = 0 ?>
                                    <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $column = $column + 1 ?>
                                  <tr>
                                    <td><?php echo e($column); ?></td>
                                    <td><a href="/resumedomains/<?php echo e($domain->name); ?>"><?php echo e($domain->name); ?></a></td>
                                    <td>
                                      <div class="btn-group">
                                      <form method="POST" action="/resumedomains/<?php echo e($domain->name); ?>">
                                          <?php echo method_field('DELETE'); ?>
                                          <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button>
                                      </form>
                                        </div>
                                    </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                    </div> 
                </div>
               </div>
                            
                            <?php else: ?>
                        <div class="col-md-3">
                          <!--<a href="inbox.html" class="btn btn-primary outline-btn btn-block m-b-10">Back to Inbox</a>-->
                          <!--  <ul class="list-unstyled mailbox-nav">-->
                          <!--      <li class="active"><a href="inbox.html"><i class="fa fa-inbox"></i>Inbox <span class="badge badge-success">4</span></a></li>-->
                          <!--      <li><a href="#"><i class="fa fa-sign-out"></i>Sent</a></li>-->
                          <!--      <li><a href="#"><i class="fa fa-file-text-o"></i>Draft</a></li>-->
                          <!--      <li><a href="#"><i class="fa fa-exclamation-circle"></i>Spam</a></li>-->
                          <!--      <li><a href="#"><i class="fa fa-trash"></i>Trash</a></li>-->
                          <!--  </ul>-->
                        </div>
                        <div class="col-md-9">
                          <div class="white-box">
                            <div class="mailbox-content">
                             <div class="mailbox-header">
                            </div>
                            
                                <div class="compose-body">
                                    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <form class="row" method="post" action="/resumedomains">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="to" class="col-md-4 control-label">Domain Name:</label>
                                            <div class="col-md-8">
                                                <input type="text" name="name" class="form-control" id="to">
                                            </div>
                                        </div>
                                        
                                <div class="compose-options">
                                    <div class="pull-right">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-send"></i> Submit</button>
                                    </div>
                                </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                          </div>
                     <?php endif; ?>
                       </div>
                      </div>
                    </div>
                    <!--End row-->
                
			   
			    </div>
        <!-- End Wrapper-->
         
      <!-- Large Modal -->
            <div  id="modal-large" class="modal fade" role="dialog">
              <div class="modal-dialog modal-lg">
            
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">New Category</h4>
                  </div>
                  <div class="modal-body">
                      <form class="row" method="post" action="/resumedomains">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="to" class="col-md-4 control-label">Domain Name:</label>
                                            <div class="col-md-8">
                                                <input type="text" name="name" class="form-control" id="to">
                                            </div>
                                        </div>
                                        
                                <div class="compose-options">
                                    <div class="pull-right">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-send"></i> Submit</button>
                                    </div>
                                </div>
                                    </form>
                  </div>
                  <div class="modal-footer">
                  </div>
                </div>
            
              </div>
            </div>
             <!-- END Large Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/admin/resume-samplesdomain.blade.php ENDPATH**/ ?>