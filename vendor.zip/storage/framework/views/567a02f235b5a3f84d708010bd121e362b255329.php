<?php $__env->startSection('content'); ?>
        <!--body wrapper start-->
        <div class="wrapper">
              
              <!--Start Page Title-->
               <div class="page-title-box">
                    <h4 class="page-title">Employers</h4>
                    <ol class="breadcrumb">
                        <li>
                            <a href="/admin-dashboard">Dashboard</a>
                        </li>
                        
                        <li class="active">
                            Employers
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                 </div>
                  <!--End Page Title-->          
           
           
               <!-- Start row-->
                <div class="row">
                    <div class="calendar-layout clearfix">
                        <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-4">
                          <div class="card-profile3">
                              <div class="p-header">
                                   <img src="assets/images/profile-picture3.png"  alt="">
                                  <h4><?php echo e($employer->cname); ?></h4>
                                  <p><?php echo e($employer->email); ?></p>
                              </div>
                              <div class="p-info">
                                  <div class="row">
                                     <div class="col-md-6 co-sm-6 col-xs-6">
                                         <div class="p-stats">
                                            <h4>Posted Jobs</h4>
                                            <p><?php echo e($employer->jobs->count()); ?></p>
                                         </div>
                                     </div>
                                     
                                     <div class="col-md-6 co-sm-6 col-xs-6">
                                         <div class="p-stats last">
                                            <h4> Applicants</h4>
                                            <p><?php echo e($employer->applications->count()); ?></p>
                                         </div>
                                     </div>
                                  </div>
                                  
                              </div> <!--/.p-info-->
                              
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>      
                 </div>
               <!-- End row-->        
			    </div>
        <!-- End Wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/admin/admin-employers.blade.php ENDPATH**/ ?>