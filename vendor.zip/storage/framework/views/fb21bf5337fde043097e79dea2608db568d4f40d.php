<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<div class="container">
     <div class="row">
         <div class="col-md-8">
                 <?php if(count($location) > 0): ?>
                 <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="column card card-body border-light shadow-lg p-3 mb-5 bg-white rounded" style="background-color:#aaa;">
      <div class="col-md-12">
      <div class="row">
    <h5 style="color:#0B0B3B;"><?php echo e($show->jobtitle); ?></h5>
    
    </div>
                  <p>Posted By: <a href="#" class="text-primary">company name</a></p>
                        <div class="row">
                 <p class="text-secondary"><?php echo e($show->jobtype); ?> | Salary: <?php echo e($show->salary); ?></p>
                 </div>
    <div class="row">
    <div class="col-md-3">
                    <img class="rounded-circle img-fluid" src="<?php echo e(asset('Images/default-logo.png')); ?>" alt="Generic placeholder image" width="140" height="140">
                  </div>
                <div class="col-md-9">
                <p class="text-dark">
                    <?php echo str_limit(strip_tags($show->summary), 200); ?> <a class="btn btn-danger pull-right" href="/jobview/<?php echo e($show->id); ?>">Apply</a>
                </p>
                </div>
     </div>
       </div> 
  </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php echo e($location->links()); ?>

                 <?php endif; ?>
             </div>
                      <div class="col-md-4">
                          <?php echo $__env->make('new.rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
         </div>
     </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/filterlocation.blade.php ENDPATH**/ ?>