<?php $__env->startSection('content'); ?>
<!--body wrapper start-->
        <div class="wrapper">
              
              <!--Start Page Title-->
               <div class="page-title-box">
                    <h4 class="page-title">Resume Templates</h4>
                    <ol class="breadcrumb">
                        <li>
                            <a href="/admin-dashboard">Dashboard</a>
                        </li>
                        <li class="active">
                            Resume Templates
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                 </div>
                  <!--End Page Title-->          
           
              <!-- Start row--> 
               <div class="col-md-12">
                <div class="white-box">
                    <?php if($resumes->count() > 0): ?>
                    <div class="row">
                        <button class="btn btn-primary pull-right" data-toggle="modal" data-target="#modal-large" type="button">New Template</button>
                        <?php echo $__env->make('admin.new-resumetemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                          <div class="card-profile">
                             <img src="<?php echo e(asset('storage/'.$resume->resume)); ?>" style="width: 100%; height: 100%;"></img>
                             <div class="" align="center">
                                 <h4><?php echo e($resume->name); ?></h4>
                                 <p><?php echo $resume->description; ?></p>
                                 <div class="btn-group">
                                <a href="<?php echo e(route('cvupload.edit', ['id' => $resume->id])); ?>" class="btn btn-primary btn-sm btn-block m-t-10">Edit</a>
                                <form method="POST" action="<?php echo e(route('cvupload.destroy', ['id' => $resume->id])); ?>">
  <?php echo method_field('DELETE'); ?>
  <?php echo csrf_field(); ?>
    <div class="field">
      <div class="control">
          <button type="submit" class="btn btn-danger">Delete </button> 
        </div>
    </div>
 </form>
                                <!-- <a href="<?php echo e(route('cvupload.destroy', ['id' => $resume->id])); ?>" class="btn btn-danger btn-sm btn-block m-t-10">Delete</a> -->
                                </div>
                             </div>
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <h2 class="header-title">Resume Template Upload</h2>
                     <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('cvupload.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label  class="col-sm-3 control-label">Name:</label>
                            <div class="col-sm-9">
                              <input class="form-control" name="name" id="inputEmail3" placeholder="Name" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="val-suggestions">Description: <span class="text-danger">*</span></label>
                            <div class="col-md-9">
                              <textarea class="form-control ckeditor" id="val-suggestions" name="description" rows="7" placeholder="Template Description"><?php echo e(old('description')); ?></textarea>
                            </div>
                          </div>
                        <div class="form-group">
                            <label  class="col-sm-3 control-label">Resume Template:</label>
                            <div class="col-sm-9">
                              <input class="form-control" id="resume" type="file" name="resume" autofocus>
                            </div>
                        </div>
                        <div class="form-group m-b-0">
                            <div class="col-sm-offset-3 col-sm-9">
                              <button type="submit" class="btn btn-primary">Upload</button>
                            </div>
                        </div>
                     </form>
                     <?php endif; ?>
                    </div>
                </div>
               </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/admin/resume.blade.php ENDPATH**/ ?>