<?php $__env->startSection("content"); ?>

    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section class="section section-top section-full">
          <div class="container"><br><br><br>
          <h5 class="text-primary">You are applying for:<?php echo e($job->jobtitle); ?></h5>
          <small class="text-danger"><i class="text-info fa fa-bell text-info"></i>Tip: Complete your profile before submitting your job application.</small>
     
<div class="panel-body">
        <?php echo $__env->make('dashboard.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clearfix"></div>
</div>

        <!-- /row -->
      </section>
    </section>
      <script>
$(document).ready(function(){
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    localStorage.setItem('activeTab', $(e.target).attr('href'));
});

var activeTab = localStorage.getItem('activeTab');
if(activeTab){
    $('.nav-tabs a[href="' + activeTab + '"]').tab('show');
}
});
</script>
    <!--main content end-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/apply.blade.php ENDPATH**/ ?>