<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="padding-top:5rem">
    <h5 style="color:#0B0B3B;" align="center">Upload Resume to get Started</h5>
<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
  	<div class="container">
      <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  	    <form action="<?php echo e(route('cvupload.store')); ?>" method="POST" enctype="multipart/form-data">
  	        <?php echo csrf_field(); ?>
  		<div class="row justify-content-center">
  	    <div class="col-md-4">
  		    <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Full Name:')); ?></label>
                            <div class="col-md-10">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="full_name" value="<?php echo e(old('full_name')); ?>" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        </div>
                        
                        
  	    <div class="col-md-4">
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email address:')); ?></label>
                                 <div class="col-md-10">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        </div>
                        
                        
  	    <div class="col-md-4">
                        <div class="form-group row">
                            <label for="resume" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Resume:')); ?></label>
                               <div class="col-md-10">
                                <input id="resume" type="file" name="resume" autofocus>

                                <?php if ($errors->has('resume')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('resume'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-info text-white">Submit</button>
                        </div>
  		</div>
  		</form>
  	</div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/upload-cv.blade.php ENDPATH**/ ?>