<div class="modal fade" id="alert" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-md-6">
                    
                </div>
                <div class="col-md-6">
              <button class="btn text-white pull-left" style="background-color:#0B0B3B;">Alert</button>  
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="image-gallery-title"></h4>
                </div>
            </div>
            <div class="modal-body">
                        
<form>
    <div class="form-group">
    <label for="name">Full Name</label>
    <input type="text" class="form-control" id="name" placeholder="Enter Full Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
</form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" style="background-color:#0B0B3B;">Create Alerts</button>
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/create-alertsmodal.blade.php ENDPATH**/ ?>