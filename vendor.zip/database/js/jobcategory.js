
// $(document).ready(function(){
//     $('#search').keyup(function(){
// var path="{{route('autocomplete.search')}}";
// $(input.filedtype).typeahead({
//     source:function(query,process){
// $.get(path,{query:name},function(data){
//     $( "#jobs" ).html( data )
// });

//     }
// });
// });
// });
 