<?php
class {CLASS}
