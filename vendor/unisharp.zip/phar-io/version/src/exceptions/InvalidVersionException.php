<?php

namespace PharIo\Version;

class InvalidVersionException extends \InvalidArgumentException implements Exception {
}
