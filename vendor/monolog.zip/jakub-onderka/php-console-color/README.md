PHP Console Color
=================

[![Build Status](https://travis-ci.org/JakubOnderka/PHP-Console-Color.svg?branch=master)](https://travis-ci.org/JakubOnderka/PHP-Console-Color)

Simple library for creating colored console ouput.

See `example.php` how to use this library.

![Example from Windows 10](https://user-images.githubusercontent.com/89590/40762008-687f909a-646c-11e8-88d6-e268a064be4c.png)