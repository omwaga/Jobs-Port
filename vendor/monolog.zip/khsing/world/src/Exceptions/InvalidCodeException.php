<?php

namespace Khsing\World\Exceptions;

/**
 * InvalidCodeException.
 */
class InvalidCodeException extends \Exception
{
}
