<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<html>
    <body>
        <div class="card">
            <div class="card-body">
            <p>Dear <b style="color: brown;font-family: 'Roboto', sans-serif;">{{$emaill}}</b></p>
            <p><b style="color: royalblue">Thank you for posting your application with us.</b></p>
            <p>You have successfully posted the following position: <strong>{{$jobtitle}}</strong>
        on behalf of  <b>{{$company}}</b> company.</p>
            <p>Thank you for choosing us as your career agents.We appreciate your services.
                            </p>
            <hr>
            <p class="text-danger"><b>Kind Regards</b></p>
            <p  style="color: saddlebrown"><b>Human Resource Officer</b></p>
            <p  style="color: saddlebrown"><b>TheNetworkedPros, Nairobi- Kenya</b></p>
            <p  style="color: saddlebrown"><b>Njema Court, Suit R2</b></p>
            <p  style="color: saddlebrown"><b>Westlands, Raptha Road</b></p>
            </div>
        </div>
    </body>
</html>