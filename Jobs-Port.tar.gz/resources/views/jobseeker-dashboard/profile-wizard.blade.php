@extends("layouts.dashboard")
@section("content")
      @include('jobseeker-dashboard.career-profile')
@endsection