<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CoverLetter extends Model
{
    protected $fillable = ['name', 'description', 'letter'];
}
