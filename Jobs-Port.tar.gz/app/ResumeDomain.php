<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResumeDomain extends Model
{
    protected $guarded = [];
}
