<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WorkProgramEnrollment extends Model
{
    protected $guarded =[];
}
