<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<html>
    <body>
        <div class="card">
            <div class="card-body">
            <p>Dear <b style="color: brown;font-family: 'Roboto', sans-serif;">{{$firstname}}</b></p>
            <p><b style="color: royalblue">Thank you for creating your company with us </b></p>
            <p>This is to inform you that you have successfully created a company profile with us. The details will be reviewed and the company approved after review. This involves follow up calls to confirm the company details: Below are the company details:
            	<p>Company name:{{$companyname}}</p>
            	<p>Industry Type:{{$cindustry}}</p>
            	<p>Location : {{$caddress}}</p>
            	<p>Company emailaddress : {{$companyemail}}</p>
            	<p>Contact person name: {{$contactperson}}</p>
            	<p>Contact No: {{$telephone}}</p>
            	<br>
            <p>Thank you for choosing us as your career agents.We appreciate your services.
                            </p>
            <hr>
            <p class="text-danger"><b>Kind Regards</b></p>
            <p  style="color: saddlebrown"><b>Human Resource Officer</b></p>
            <p  style="color: saddlebrown"><b>The Networked Pros, Nairobi- Kenya</b></p>
            <p  style="color: saddlebrown"><b>Njema Court, Suit R2</b></p>
            <p  style="color: saddlebrown"><b>Westlands, Raptha Road</b></p>
            </div>
        </div>
    </body>
</html>