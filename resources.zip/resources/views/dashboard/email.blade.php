<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<html>
    <body>
        <div class="card">
            <div class="card-body">
            <p>Dear <b style="color: brown;font-family: 'Roboto', sans-serif;">{{$namee}}</b></p>
            <p><b style="color: royalblue">Thank you creating a company with us</b></p>
            <p>This is to inform you that you have created your company profile successfully. Your company is <strong>{{$cname}}</strong>
        located at <b>{{$location}}</b>..</p>
        <p>
         One of our team members will follow up with you to confirm the 
         details and location for security purposes. Kindly Use the following link to login to your profile
        http://thenetworkedpros.com/Employer
            </p>
            <p>We thank you for creating your profile with us.
            </p>
            <hr>
            <p class="text-danger"><b>Kind Regards</b></p>
            <p  style="color: saddlebrown"><b>Human Resource Officer</b></p>
            <p  style="color: saddlebrown"><b>Career hub Center, Nairobi- Kenya</b></p>
            <p  style="color: saddlebrown"><b>Njema Court, Suit R2</b></p>
            <p  style="color: saddlebrown"><b>Westlands, Raptha Road</b></p>
            </div>
        </div>
    </body>
</html>