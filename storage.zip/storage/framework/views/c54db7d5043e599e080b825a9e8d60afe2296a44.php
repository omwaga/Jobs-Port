<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<div class="container">

     <div class="row">
         
         <div class="col-md-8">
                         <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="card card-body border-light shadow-lg p-3 mb-5 bg-white rounded" style="background-color:#aaa;">
      <div class="col-md-12">
      <div class="row">
    <h5 style="color:#0B0B3B;"><a href="#"><?php echo e($application->job->jobtitle); ?></a></h5>
    
    </div>
                  <p>Posted By: <a href="#" class="text-primary"><?php echo e($application->employer->company_name); ?></a></p>
                        <div class="row">
                 <p class="text-secondary"><?php echo e($application->job->jobtype); ?> | Salary: <?php echo e($application->job->salary); ?></p>
                 <!--<div class="col-md-12">-->
                 <!--<a class="btn btn-danger pull-right" href="#">Details</a>-->
                 <!--</div>-->
                 </div>
       </div> 
  </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
             </div>
                      <div class="col-md-4">   
                   <?php echo $__env->make('dashboard.rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
        
     </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/applications.blade.php ENDPATH**/ ?>