<?php $__env->startSection('content'); ?>
<div class="dashboard-wrapper">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row  p-2">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h5 class="pageheader-title">Staff Recruitment and Development</h5>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="/Employer-dashboard" class="breadcrumb-link">Dashboard</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Source Candidates</li>
                                    </ol>
                                      <a href="<?php echo e(route('picktemplate')); ?>" class=" btn btn-sm btn-success float-right text-white">Pick a Template</a>
                                    </nav>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                              <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             	    <form role="form" method="post" action="<?php echo e(route('postempjob')); ?>">
             	        <?php echo csrf_field(); ?>
             	        <div class="row p-3">
            <div class="col-md-6 col-sm-6 col-xs-12">
                        
                                        <div class="form-group">
                                            <label class="col-form-label">Enter job title:</label>
                                            <input data-parsley-minlength="3" class="form-control" type="text" name="jobtitle" value="<?php echo e(old('jobtitle')); ?>" required="" />
                                        </div>
                                       <div class="form-group">
                                            <label>Select Job Type:</label>
                                            <select class="form-control" name="positiontype" required>
                                                <option>Part-time</option>
                                                <option>Full-time</option>
                                                <option>Contract</option>
                                                <option>Internship</option>
                                            </select>
                                        </div>
                                             <div class="form-group">
                                            <label>Select Category:</label>
                                            <select class="form-control" name="jfunction" required>
                                              <?php $__currentLoopData = $jobcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jobc->id); ?>"><?php echo e($jobc->jobcategories); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Expiry date:</label>
                                            <input class="form-control" value="<?php echo e(old('expiry')); ?>" type="date" name="expiry" required />
                             
                        </div>
                            </div>
               <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                      
                        <div class="panel-body">
                          <div class="form-group">
                                        <label>Select Industry:</label>
                                            <select class="form-control" name="industry" required>
                                               <?php $__currentLoopData = $industry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($indust->id); ?>"><?php echo e($indust->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                             <div class="form-group">
                                            <label>Select Country:</label>
                                            <select class="form-control" name="country" required>
                                                <option>Select Country</option>
                                            	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            	<option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Select Town/County:</label>
                                            <select class="form-control" name="state" required>
                                                <option>Select Town/County</option>
                                                <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($town->id); ?>"><?php echo e($town->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                <div class="form-group">
                                            <label>Salary Specification:</label>
                                            <input class="form-control <?php if ($errors->has('salary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('salary'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('salary')); ?>"  type="text" name="salary" required />
                                            <?php if ($errors->has('salary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('salary'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                 
                                        </div>
                                         <div class="form-group">
                                             <input type="hidden" hidden class="form-control" id="formGroupExampleInput" placeholder=""
                                                        required autofocus name="emaill" value="<?php echo Auth::guard('employer')->user()->email ?>"> 
                                        </div>
                                         <div class="form-group">
                                         <?php $__currentLoopData = $cname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" hidden class="form-control" id="formGroupExampleInput" placeholder=""
                                            required autofocus name="company" value="<?php echo $item->cname ?>">  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                            </div>
                        </div>
                            </div>
                            </div>
                            
                                                         <div class="col-md-12">
                             <div class="panel panel-dark">
                                        <div class="form-group">
                                            <label>Job Summary:</label>
                                            <textarea class="form-control ckeditor" id="summary-ckeditor" rows="4" name="jsummary" id="summary" required><?php echo e(old('jsummary')); ?></textarea>
                                        </div> 
                             </div>   
                            </div>
                            <div class="col-md-12">
                             <div class="panel panel-dark">
                                <div class="form-group">
                                            <label>Job Description:</label>
                                            <textarea class="form-control <?php if ($errors->has('jdescription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jdescription'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> ckeditor" rows="20" name="jdescription" id="descc" required><?php echo e(old('jdescription')); ?></textarea>
                                            <?php if ($errors->has('jdescription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jdescription'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div> 
                             </div>   
                            </div>

        <div class="col-md-12">
<div class="form-group">
                            <label>Apply with us?</label>
                            <div class="checkbox">
                                <label>
                    <input type="checkbox" value="Yes" name="apply" />Check the box to receive the job applications using our portal. </label>
                                            </div>
                                        </div>
        </div>                 
    <div class="col-md-12">
                             <div class="panel panel-dark">
                                        <div class="form-group">
                                            <label>Application details</label>
                                            <textarea class="form-control ckeditor" name="application" rows="3" ><?php echo e(old('application')); ?></textarea>
                                        </div>
                             </div>   
                            </div>
        <button type="submit" class="btn btn-danger float-right btn-sm"><i class="fa fa-save"></i>Post Job </button>
        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                               </form>
                </div>
            </div>
                </div>
                <script type="text/javascript">
    jQuery(document).ready(function ()
    {
            jQuery('select[name="country"]').on('change',function(){
               var countryID = jQuery(this).val();
               if(countryID)
               {
                  jQuery.ajax({
                     url : 'dropdownlist/getstates/' +countryID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="state"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="state"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="state"]').empty();
               }
            });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer.employer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/empdash/content/postjob.blade.php ENDPATH**/ ?>