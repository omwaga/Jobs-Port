<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<div class="container">
    <div class="row">
        <div class="col-lg-7">
            <h4 style="color:#0B0B3B;"><?php echo e($blog->title); ?></h4>
            
            <p>Category: <b class="text-primary"><?php echo e($blog->category->name); ?> | <?php echo e($blog->created_at); ?></b></p>

                        <hr>
                        <p><?php echo $blog->description; ?></p>
        </div>
        
        <div class="col-lg-4">
         <?php echo $__env->make('new.blog-rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- verticaladd -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9415122333094581"
     data-ad-slot="5481420996"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/blog-articleview.blade.php ENDPATH**/ ?>