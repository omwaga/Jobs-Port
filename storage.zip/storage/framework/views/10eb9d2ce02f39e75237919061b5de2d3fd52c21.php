<?php $__env->startSection('content'); ?>

<!--body wrapper start-->
<div class="wrapper">

  <!--Start Page Title-->
  <div class="page-title-box">
    <h4 class="page-title">Post a Job</h4>
    <ol class="breadcrumb">
      <li>
        <a href="<?php echo e(route('admin')); ?>">Dashboard</a>
      </li>
      <li>
        <a href="<?php echo e(route('adminvacancies')); ?>">Job Vacancies</a>
      </li>
      <li class="active">
        Create Job Post
      </li>
    </ol>
    <div class="clearfix"></div>
  </div>
  <!--End Page Title-->          


  <!--Start row-->
  <form method="POST" action="<?php echo e(route('admin_savejob')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
      <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-md-6">
        <div class="white-box">
          <div class="form-group">
            <label>Job Title</label>
            <input class="form-control" value="<?php echo e(old('jobtitle')); ?>" name="jobtitle"  placeholder="Enter Title" type="text">
          </div>
          <div class="form-group">
            <label>Job Type</label>
            <select name="jobtype" class="form-control">
              <option>Select Type</option>
              <option>Job Type</option>
              <option>Full Time</option>
              <option>Contract</option>
              <option>Internship</option>
            </select>
          </div>
          <div class="form-group">
            <label>Job Category</label>
            <select name="jobcategories_id" class="form-control">
              <option>Select Category</option>
              <?php $__currentLoopData = $jobcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($jobcategory->id); ?>"><?php echo e($jobcategory->jobcategories); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label>Expiry Date</label>
            <input name="expirydate" value="<?php echo e(old('expirydate')); ?>" class="form-control" placeholder="mm/dd/yyyy" type="date" id="datepicker-autoclose">
          </div>
        </div>
      </div> <!--/.col-md-6-->


      <div class="col-md-6">
       <div class="white-box">
        <div class="form-group">
          <label  class="control-label">Job Industry</label>
          <select name="industry" class="form-control">
            <option>Select Industry</option>
            <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($industry->id); ?>"><?php echo e($industry->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label  class="control-label">Country</label>
          <select name="country_id" class="form-control">
            <option>Select Country</option>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label  class="control-label">Town/State</label>
          <select name="location" class="form-control">
            <option>Select Town</option>
            <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($town->id); ?>"><?php echo e($town->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label class="control-label">Salary<small> (if confidential leave blank)</small></label>
          <input name="salary" value="<?php echo e(old('salary')); ?>" class="form-control" placeholder="00.00" type="text">
        </div>
      </div>
    </div><!-- /.col-md-6-->

  </div>
  <!--End row-->
  <!--Start row-->
  <div class="row">
   <div class="col-md-12">
     <div class="white-box">
      <div class="form-group">
        <label class="control-label">Job Summary</label>
        <div class="col-md-12">
          <textarea name="summary" class="form-control ckeditor" id="val-suggestions"><?php echo e(old('summary')); ?></textarea>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label">Job Description</label>
        <div class="col-md-12">
          <textarea name="description" class="form-control ckeditor" id="val-suggestions"><?php echo e(old('description')); ?></textarea>
        </div>
      </div>
      <div class="form-group">
        <div class="checkbox primary">
          <input  type="checkbox" name="apply" value="<?php echo e(old('apply')); ?>" id="checkbox1"> <label for="checkbox1"> Apply With Us  <small>(Select if you want to receive the applications via the networkedpros portal)</small> </label>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label">Application Details</label>
        <div class="col-md-12">
          <textarea name="applicationdet" class="form-control ckeditor" id="val-suggestions"><?php echo e(old('applicationdet')); ?></textarea>
        </div>
      </div> 
      <button type="submit" class="btn btn-success">Submit</button> 
    </div>
  </div>
</div>
</form>
<!--End row-->

</div>
<!-- End Wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/admin/create-job.blade.php ENDPATH**/ ?>