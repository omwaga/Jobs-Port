<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet"> 
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"> 

<!--
    instagram: www.instagram.com/programmingtutorial
    site: programlamadersleri.net
-->

<div class="portfolio">
      <div class="container">
            
            <div class="row">
                    <div class="col-lg-6 col-lg-offset-3 text-center">  
                        <h1><span class="ion-minus"></span>Our Works<span class="ion-minus"></span></h1>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis  dis parturient montes, nascetur ridiculus </p><br>
                    </div> 
            </div>  
                
            <div class="row">
                
                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/207665/pexels-photo-207665.jpeg?h=350&auto=compress&cs=tinysrgb" alt="">
                        </a>
                                                                                
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/401107/pexels-photo-401107.jpeg?h=350&auto=compress&cs=tinysrgb" alt="">
                        </a>
                                                                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/311458/pexels-photo-311458.jpeg?w=1260&h=750&auto=compress&cs=tinysrgb" alt="">
                        </a>
                                                                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/6253/city-street-typography-design.jpg?h=350&auto=compress&cs=tinysrgb" alt="">
                        </a>
                                                                        
                    </div>
                   
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/414974/pexels-photo-414974.jpeg?h=350&auto=compress&cs=tinysrgb" alt="">
                        </a>
                                                                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/137141/pexels-photo-137141.jpeg?h=350&auto=compress&cs=tinysrgb" alt="">
                        </a>
                                                                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded" src="https://images.pexels.com/photos/436784/pexels-photo-436784.jpeg?h=350&auto=compress&cs=tinysrgb">
                        </a>
                                                                        
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                       
                        <a href="#">
                            <img class="img-rounded"  src="https://images.pexels.com/photos/121734/pexels-photo-121734.jpeg?h=350&auto=compress&cs=tinysrgb">
                        </a>
                                                                        
                    </div>
                  
            </div>  
                
    </div>
</div><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/pick-resume.blade.php ENDPATH**/ ?>