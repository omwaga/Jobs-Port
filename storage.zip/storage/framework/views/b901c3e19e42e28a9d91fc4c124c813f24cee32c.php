<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'The NetworkedPros'); ?> </title>
    <link rel="shortcut icon" href="/images/logo/Networked.jpg">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
      <link rel="shortcut icon" href="<?php echo e(asset('Images/logo/Networked.jpg')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link href="<?php echo e(asset('assets/plugins/bootstrap-editable/css/bootstrap-editable.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL STYLES -->
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <!-- <link id="theme-style" rel="stylesheet" href="resume/css/orbit-1.css"> -->
    <link href="<?php echo e(asset('resume/navbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/footer.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="resume/style.css">
<link href='http://fonts.googleapis.com/css?family=Rokkitt:400,700|Lato:400,300' rel='stylesheet' type='text/css'>
</head>
<body style="background-color: #fff; padding-top: 2rem;">
    <div id="app">
        <?php echo $__env->make('navigation.resume-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main style="padding-top: 9rem; ">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
         
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Begin core plugin -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/moment/moment.js')); ?>"></script>
    <!-- <script  src="<?php echo e(asset('assets/js/jquery.slimscroll.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.nicescroll.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script> -->
    <!-- End core plugin -->

    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="<?php echo e(asset('assets/plugins/bootstrap-editable/js/bootstrap-editable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/bootstrap-editable-custom.js')); ?>"></script>
    <!-- BEGIN PAGE LEVEL SCRIPTS -->

</body>

</html>
<?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/layouts/resume-app.blade.php ENDPATH**/ ?>