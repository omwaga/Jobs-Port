<footer class="p-5 bg-theme text-small" style="color:#fff;margin-top:0px;">
    <div class="container">
        <div class="row">
           
            <div class="col-12 col-sm-12 col-md-9">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <h5 style="color: #F4A506">Job Seekers</h5>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('alljobs')); ?>"class="text-white">Browse Latest Jobs Jobs</a></li>
                            <li><a href="<?php echo e(route('jobseekerregister')); ?>" class="text-white">Create Career Profile</a></li>
                            <li><a href="#" class="text-white">Work Readiness Program</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-6">
                        <h5 style="color: #F4A506">Employers</h5>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('hirre')); ?>" class="text-white">Create Account</a></li>
                             <li><a href="<?php echo e(route('foremployer')); ?>"class="text-white">Post a Job</a></li>
                        </ul>
                    </div>
                </div>
            </div>
             <div class="col-12 col-sm-12 col-md-3 text-white">
           <div class="col-12 col-sm-10">
                        <h5 style="color: #F4A506">Resume Builder</h5>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white">CV Design</a></li>
                            <li><a href="#" class="text-white">Cover Letter Design</a></li>
                        </ul>
                    </div>
            </div>
        </div><hr>
        <!-- <hr>
        <ul class="list-unstyled list-inline mb-0 text-center">
            <li class="list-inline-item">
                <a href="#">
                    <img src="https://www.vectorvest.com/wp-content/themes/vectorvest/images/social-facebook-white.png" alt="">
                </a>
            </li>
            <li class="list-inline-item">
                <a href="#">
                    <img src="https://www.vectorvest.com/wp-content/themes/vectorvest/images/social-twitter-white.png" alt="">
                </a>
            </li>
            <li class="list-inline-item">
                <a href="#">
                    <img src="https://www.vectorvest.com/wp-content/themes/vectorvest/images/social-googleplus-white.png" alt="">
                </a>
            </li>
            <li class="list-inline-item">
                <a href="#">
                    <img src="https://www.vectorvest.com/wp-content/themes/vectorvest/images/social-linkdin-white.png" alt="">
                </a>
            </li>
            <li class="list-inline-item">
                <a href="#">
                    <img src="https://www.vectorvest.com/wp-content/themes/vectorvest/images/social-youtube-white.png" alt="">
                </a>
            </li>
        </ul>
        <hr> -->

        <div class="col-12 text-center text-white">
            <p>©<script>document.write(new Date().getFullYear());</script> The Networked Pros. All Rights Reserved.</p>
        </div>
    </div>
</footer><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/footer/footer.blade.php ENDPATH**/ ?>