<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/success.blade.php ENDPATH**/ ?>