<?php $__env->startSection('content'); ?>
<!--body wrapper start-->
        <div class="wrapper">
              
              <!--Start Page Title-->
               <div class="page-title-box">
                    <h4 class="page-title">Cover Letter Templates</h4>
                    <ol class="breadcrumb">
                        <li>
                            <a href="/admin-dashboard">Dashboard</a>
                        </li>
                        <li class="active">
                            Cover Letter Templates
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                 </div>
                  <!--End Page Title-->          
           
              <!-- Start row--> 
               <div class="col-md-12">
                <div class="white-box">
                    <?php if($cover_letters->count() > 0): ?>
                    <div class="row">
                        <button class="btn btn-primary pull-right" data-toggle="modal" data-target="#modal-large" type="button">New Template</button>
                    </div>
                    <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php $__currentLoopData = $cover_letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cover_letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                          <div class="card-profile">
                             <img src="<?php echo e(asset('storage/'.$cover_letter->cover_letter)); ?>" style="width: 100%; height: 100%;"></img>
                             <div class="" align="center">
                                 <h4><?php echo e($cover_letter->name); ?></h4>
                                 <p><?php echo $cover_letter->description; ?></p>
                                 <div class="btn-group">
                                <a href="<?php echo e(route('coverletters.edit', ['id' => $cover_letter->id])); ?>" class="btn btn-primary btn-sm btn-block m-t-10">Edit</a>
                                <form method="POST" action="<?php echo e(route('coverletters.destroy', ['id' => $cover_letter->id])); ?>">
  <?php echo method_field('DELETE'); ?>
  <?php echo csrf_field(); ?>
    <div class="field">
      <div class="control">
          <button type="submit" class="btn btn-danger">Delete </button> 
        </div>
    </div>
 </form>
                                </div>
                             </div>
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <h2 class="header-title">Cover Letter Template Upload</h2>
                     <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('coverletters.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label  class="col-sm-3 control-label">Name:</label>
                            <div class="col-sm-9">
                              <input class="form-control" value="<?php echo e(old('name')); ?>" name="name" id="inputEmail3" placeholder="Name" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="val-suggestions">Description: <span class="text-danger">*</span></label>
                            <div class="col-md-9">
                              <textarea class="form-control ckeditor" id="val-suggestions" name="description" rows="7" placeholder="Template Description"><?php echo e(old('description')); ?></textarea>
                            </div>
                          </div>
                        <div class="form-group">
                            <label  class="col-sm-3 control-label">Cover Letter Template:</label>
                            <div class="col-sm-9">
                              <input class="form-control" id="cover_letter" type="file" name="cover_letter" autofocus>
                            </div>
                        </div>
                        <div class="form-group m-b-0">
                            <div class="col-sm-offset-3 col-sm-9">
                              <button type="submit" class="btn btn-primary">Upload</button>
                            </div>
                        </div>
                     </form>
                     <?php endif; ?>
                    </div>
                </div>
               </div>
               <?php echo $__env->make('admin.add-coverlettermodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/admin/cover-letter.blade.php ENDPATH**/ ?>