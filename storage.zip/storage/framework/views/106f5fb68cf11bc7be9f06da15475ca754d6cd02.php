<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : African Daisy 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20111031

-->
<html>
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Africandaisy by TEMPLATED</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
    <div id="page">
        <div id="content">
            <div class="post">
                <h2 class="title">Personal Information</h2>
                <div style="clear: both;">&nbsp;</div>
                <div class="entry">
                    <p style="width: 60%"><?php echo e($personalstatements->statement  ?? ''); ?></p>
                </div>
            </div>
            <div class="post">
                <h2 class="title">Experience</h2>
                <p class="meta"><span class="date">November 07, 2011</span></p><br>
                <div style="clear: both;">&nbsp;</div>
                <?php $__currentLoopData = $experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienced): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="entry">
                    <label style="width: 60%"><strong>Employer:</strong><?php echo e($experienced->employer); ?></label>
                    <label style="width: 60%"><strong>Position:</strong><?php echo e($experienced->position); ?></label>
                    <!-- <p style="width: 60%"><strong>Roles and Resposiblities:</strong><?php echo e($experienced->roles); ?></p> -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="post">
                <h2 class="title">Education</h2>
                <p class="meta"><span class="date">November 07, 2011</span></p><br>
                <div style="clear: both;">&nbsp;</div>
                <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="entry">
                    <label style="width: 60%"><strong>Institution:</strong><?php echo e($educated->institution); ?></label>
                    <label style="width: 60%"><strong>Qualification:</strong><?php echo e($educated->Qualification); ?></label>
                    <!-- <p style="width: 60%"><strong>Roles and Resposiblities:</strong><?php echo e($experienced->roles); ?></p> -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- end #content -->
        <div id="sidebar">
            <ul>
                <li>
                    <h4><?php echo e($personalinfo->name  ?? ''); ?></h4>
                    <ul>
                        <li><?php echo e($personalinfo->email  ?? ''); ?></li>
                        <li><strong>Phone:</strong><?php echo e($personalinfo->phone  ?? ''); ?></li>
                        <li><strong>Gender:</strong><?php echo e($personalinfo->gender  ?? ''); ?></li>
                        <li><strong>Religion:</strong><?php echo e($personalinfo->religion  ?? ''); ?></li>
                        <li><strong>DOB:</strong><?php echo e($personalinfo->dob  ?? ''); ?></li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- end #sidebar -->
    </div>
    <!-- end #page -->
</div>
</body>
</html>
<?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/orbit-template.blade.php ENDPATH**/ ?>