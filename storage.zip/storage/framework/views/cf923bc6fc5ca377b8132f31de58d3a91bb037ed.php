<?php $__env->startSection('content'); ?>
<div class="jumbotron jumbotron-fluid" style="background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0)), url(<?php echo e(asset('Images/cv2.jpg')); ?>)" style=" padding-top: 5rem;">
  <div class="container">
              <form method="get" action="<?php echo e(route('homesearch')); ?>">
             <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12 p-0">
               <select name="industry" class="form-control search-slt">
                  <option>All Job Industries</option>
                  <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($industry->id); ?>"><?php echo e($industry->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

          </div>
          <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                            <select name="job_category" class="form-control search-slt">
                  <option>All Job Functions</option>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($jobt->id); ?>"><?php echo e($jobt->jobcategories); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 p-0">
                          <select name="country" class="form-control search-slt">
                       <option value="">Select Country</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select> 
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 p-0">
                          <select name="state" class="form-control search-slt">
                       <option>State/Region</option>
              </select> 
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 p-0">
             <button type="submit" class="btn btn-danger wrn-btn">Search</button>
          </div>
          </div>
          </form>
    </div>
  </div>
<div class="container">
     <div class="row">
         <div class="col-md-8">
          <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="card card-body border-light shadow-lg p-3 mb-5 bg-white rounded" style="background-color:#aaa;">
      <div class="col-md-12">
      <div class="row">
        <?php $jobtitle = str_slug($job->jobtitle, '-'); ?>
    <h5 style="color:#0B0B3B;"><a href="/jobview/<?php echo e($job->id); ?>/<?php echo e($jobtitle); ?>"><?php echo e($job->jobtitle); ?></a></h5>
    
    </div>
                  <p>Posted By: <a href="" class="text-primary"><?php echo e($job->employer->company_name); ?></a></p>
                        <div class="row">
                 <p class="text-secondary"><?php echo e($job->jobtype); ?> | Salary: <?php echo e($job->salary); ?></p>
                 </div>
    <div class="row">
    <div class="col-md-3">
                    <img class="rounded-circle img-fluid" src="<?php echo e(asset('storage/logos/'.$job->employer->logo)); ?>" alt="<?php echo e($job->jobtitle); ?>" width="140" height="140">
                  </div>
                <div class="col-md-9">
                <p class="text-dark">
                    <?php echo str_limit($job->summary, $limit = 300, $end = '...'); ?><a class="btn btn-danger pull-right" href="/jobview/<?php echo e($job->id); ?>/<?php echo e($jobtitle); ?>">Apply</a>
                </p>
                </div>
     </div>
       </div> 
  </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <?php echo e($jobs->links()); ?>

             </div>
                      <div class="col-md-4">
                           <?php echo $__env->make('new.rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
         </div>
     </div>

</div>
<script type="text/javascript">
    jQuery(document).ready(function ()
    {
            jQuery('select[name="country"]').on('change',function(){
               var countryID = jQuery(this).val();
               if(countryID)
               {
                  jQuery.ajax({
                     url : 'dropdownlist/getstates/' +countryID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="state"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="state"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="state"]').empty();
               }
            });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/all-jobs.blade.php ENDPATH**/ ?>