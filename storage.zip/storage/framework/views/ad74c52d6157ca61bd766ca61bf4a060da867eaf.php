<?php $__env->startSection('content'); ?>
<div class="container"  style=" padding-top: 5rem;">

     <div class="row">
         <div class="col-md-8">
             <?php if(!$articles->count()): ?>
             <p>No articles yet</p>
             <?php endif; ?>
          <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="card card-body border-light shadow-lg p-3 mb-5 bg-white rounded" style="background-color:#aaa;">
      <div class="col-md-12">
      <div class="row">
    <h5><a href="/blog/<?php echo e($article->title); ?>"  style="color:#0B0B3B;"><?php echo e($article->title); ?></a></h5>
    
    </div>
                        <div class="row">
                 <p class="text-secondary"><?php echo e($article->category->name); ?> | <?php echo e($article->created_at); ?></p>
                 </div>
    <div class="row">
    <div class="col-md-3">
                    <img class="rounded-circle img-fluid" src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>" alt="Generic placeholder image" width="140" height="140">
                  </div>
                <div class="col-md-9">
                <p class="text-dark">
                    <?php echo str_limit($article->description, $limit = 300, $end = '...'); ?><a class="btn pull-right text-white btn-sm" style="background-color:#0B0B3B;" href="/blog/<?php echo e($article->title); ?>">Read More</a>
                </p>
                </div>
     </div>
       </div> 
  </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <?php echo e($articles->links()); ?>

             </div>
         <div class="col-md-4">  
         <?php echo $__env->make('new.blog-rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
     </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/blog-article.blade.php ENDPATH**/ ?>