<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 6rem">
	<div class="row">
		<div class="col-lg-10 offset-lg-1 text-left">
			<h4 class="display-6 font-weight-bold">Enroll to the Work Readiness program</h4>
			<form method="Post" action="<?php echo e(route('enrollwork')); ?>">
				<?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php echo csrf_field(); ?>
				<div class="form-group">
					<label>Full Name:</label>
					<input class="form-control <?php if ($errors->has('full_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('full_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('full_name')); ?>" type="text" name="full_name">
					<?php if ($errors->has('full_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('full_name'); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<label>Email Address:</label>
					<input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('email')); ?>" type="email" name="email">
					<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<label>Phone Number:</label>
					<input class="form-control <?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('phone_number')); ?>" type="text" name="phone_number">
					<?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<label>Country:</label>
					<select name="country" class="form-control">
						<option value="">Select Country</option>
						<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group">
					<label>Select Programs to Enroll:</label><br>
					<label class="checkbox-inline pl-3">
						<input  type="checkbox" value="Career Planning" name="career_planning">Career Planning
					</label>
					<label class="checkbox-inline pl-3">
						<input  type="checkbox" value="Job Preparation" name="job_preparation">Job Preparation
					</label>
					<label class="checkbox-inline pl-3">
						<input  type="checkbox" value="Workplace Skills" name="workplace_skills">Workplace Skills
					</label>
					<label class="checkbox-inline pl-3">
						<input  type="checkbox" value="Personal Development" name="personal_development">Personal Development
					</div>
				</label>
				<label class="checkbox-inline pl-3">
					<input  type="checkbox" value="Basic IT Skills for the Modern Office" name="it_skills">Basic IT Skills for the Modern Office
				</label>
				<label class="checkbox-inline pl-3">
					<input  type="checkbox" value="Business Skills" name="business_skills">Business Skills (Optional)
				</label>
				<label class="checkbox-inline pl-3">
					<input  type="checkbox" value="Consultancy Skills" name="consultancy_skills">Consultancy Skills (Optional)
				</label>
				<div>
					<button class="btn btn-success">Submit</button>
				</div>
			</form>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/enroll-workprogram.blade.php ENDPATH**/ ?>