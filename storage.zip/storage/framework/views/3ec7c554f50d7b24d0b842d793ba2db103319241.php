<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="container">
 <div class="row">
<div class="col-md-8">
    <label>Current Search: current search</label>
<div class="row">
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card card-body border-light shadow-lg p-3 mb-5 bg-white rounded" style="background-color:#aaa;">
      <div class="col-md-12">
      <div class="row">
    <h5 style="color:#0B0B3B;"><?php echo e($result->jobtitle); ?></h5>
    
    </div>
                  <p>Posted By: <a href="#" class="text-primary"><?php echo e($result->cprofile->cname); ?></a></p>
                        <div class="row">
                 <p class="text-secondary"><?php echo e($result->jobtype); ?> | Salary: <?php echo e($result->salary); ?></p>
                 </div>
    <div class="row">
    <div class="col-md-3">
                    <img class="rounded-circle img-fluid" src="<?php echo e(asset('Images/default-logo.png')); ?>" alt="Generic placeholder image" width="140" height="140">
                  </div>
                <div class="col-md-9">
                <p class="text-dark">
                    <?php echo str_limit($result->summary, $limit = 300, $end = '...'); ?> <a class="btn btn-danger pull-right" href="<?php echo e(url('dashboard/show',[$result->id])); ?>">Details</a>
                </p>
                </div>
     </div>
     </div>   
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<div class="col-md-4">
    <?php echo $__env->make('dashboard.rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
                                
                                              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/searchjob.blade.php ENDPATH**/ ?>