<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 6rem">
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-6">
            <a class="btn text-white" href="<?php echo e(action('DashboardController@downloadresume', auth()->user()->id)); ?>" style="background-color:#0B0B3B;">Download Resume</a>
            </div>
            <div class="col-md-6">
                <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="col-md-8">
          <div id="wrapper">
            <div id="page"> 
                <div id="content" style="padding-left: 50px">
                    <div class="post">
                        <h2 class="title">Personal Information</h2>
                        <div style="clear: both;">&nbsp;</div>
                        <div class="entry">
                            <p style="width: 60%"><?php echo e($personalstatements->statement  ?? ''); ?></p>
                        </div>
                    </div>
                    <div class="post">
                        <h2 class="title">Experience</h2>
                        <p class="meta"><span class="date">November 07, 2011</span></p><br>
                        <div style="clear: both;">&nbsp;</div>
                        <?php $__currentLoopData = $experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienced): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="entry">
                            <label style="width: 60%"><strong>Employer:</strong><?php echo e($experienced->employer); ?></label>
                            <label style="width: 60%"><strong>Position:</strong><?php echo e($experienced->position); ?></label>
                            <!-- <p style="width: 60%"><strong>Roles and Resposiblities:</strong><?php echo e($experienced->roles); ?></p> -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="post">
                        <h2 class="title">Education</h2>
                        <p class="meta"><span class="date">November 07, 2011</span></p><br>
                        <div style="clear: both;">&nbsp;</div>
                        <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="entry">
                            <label style="width: 60%"><strong>Institution:</strong><?php echo e($educated->institution); ?></label>
                            <label style="width: 60%"><strong>Qualification:</strong><?php echo e($educated->Qualification); ?></label>
                            <!-- <p style="width: 60%"><strong>Roles and Resposiblities:</strong><?php echo e($experienced->roles); ?></p> -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <!-- end #content -->
                <div id="sidebar">
                    <ul>
                        <li>
                            <h4><?php echo e($personalinfo->name  ?? ''); ?></h4>
                            <ul>
                                <li class="text-white"><?php echo e($personalinfo->email  ?? ''); ?></li>
                                <li class="text-white"><strong>Phone:</strong><?php echo e($personalinfo->phone  ?? ''); ?></li>
                                <li class="text-white"><strong>Gender:</strong><?php echo e($personalinfo->gender  ?? ''); ?></li>
                                <li class="text-white"><strong>Religion:</strong><?php echo e($personalinfo->religion  ?? ''); ?></li>
                                <li class="text-white"><strong>DOB:</strong><?php echo e($personalinfo->dob  ?? ''); ?></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- end #sidebar -->
            </div>
            <!-- end #page -->
        </div>
    </div>
    <div class="col-md-4">
        <h5 class="">Select a template to preview</h5>
        <img src="<?php echo e(asset('resume/free-resume-cv-bootstrap-template-for-developer-color-1.jpg')); ?>" style="width: 150px; height: 150px">
        <img src="<?php echo e(asset('resume/free-resume-cv-bootstrap-template-for-developer-color-2.jpg')); ?>" style="width: 150px; height: 150px">
        <img src="<?php echo e(asset('resume/free-resume-cv-bootstrap-template-for-developer-color-3.jpg')); ?>" style="width: 150px; height: 150px">
        <img src="<?php echo e(asset('resume/free-resume-cv-bootstrap-template-for-developer-color-4.jpg')); ?>" style="width: 150px; height: 150px">
        <img src="<?php echo e(asset('resume/free-resume-cv-bootstrap-template-for-developer-color-5.jpg')); ?>" style="width: 150px; height: 150px">
        <img src="<?php echo e(asset('resume/free-resume-cv-bootstrap-template-for-developer-color-6.jpg')); ?>" style="width: 150px; height: 150px">
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/resume-previews.blade.php ENDPATH**/ ?>