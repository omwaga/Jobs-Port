<?php $__env->startSection('content'); ?>
        <!--body wrapper start-->
        <div class="wrapper">
              
              <!--Start Page Title-->
               <div class="page-title-box">
                    <h4 class="page-title">Jobseekers</h4>
                    <ol class="breadcrumb">
                        <li>
                            <a href="/admin-dashboard">Dashboard</a>
                        </li>
                        
                        <li class="active">
                            Jobseekers
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                 </div>
                  <!--End Page Title-->          
           
           
               <!-- Start row-->
                <div class="row">
                    <div class="calendar-layout clearfix">
                        <!--<div class="col-md-12">-->
                      <div class="row">
                         <?php $__currentLoopData = $jobseekers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobseeker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="col-md-4">
                             <div class="user-box">
                                 <div class="user-img">
                                     <img src="assets/images/users/avatar-3.jpg"  alt=""/>
                                 </div>
                                 <div class="user-info">
                                    <h4><?php echo e($jobseeker->name); ?></h4>
                                    <p><?php echo e($jobseeker->email); ?></p>
                                    <span>Jobseeker</span>
                                 </div>
                             </div>
                         </div> <!-- /.col-md-3-->
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  <!--</div>-->
                    </div>      
                 </div>
                 <?php echo e($jobseekers->links()); ?>

               <!-- End row-->        
			    </div>
        <!-- End Wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/admin/admin-jobseekers.blade.php ENDPATH**/ ?>