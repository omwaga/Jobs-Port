<?php $__env->startSection('content'); ?>
<div class="jumbotron jumbotron-fluid" style="background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0)), url(<?php echo e(asset('Images/cv2.jpg')); ?>)" style=" padding-top: 5rem;">
  
  </div>
<div class="container">
     <div class="row">
     	<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-3 col-sm-6">

            <div class="card hovercard">
                <div class="cardheader">

                </div>
                <div class="avatar">
                    <img alt="" src="<?php echo e(asset('Images/default-logo.png')); ?>">
                </div>
                <div class="info">
                    <div class="title">
                        <a target="_blank" href=""><?php echo e($company->cname); ?></a>
                    </div>
                    <div class="desc"><?php echo e($company->country); ?></div>
                    <a href="" class="btn text-white" style="background-color: #0B0B3B">View Profile</a>
                </div>
            </div>

        </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/all-companies.blade.php ENDPATH**/ ?>