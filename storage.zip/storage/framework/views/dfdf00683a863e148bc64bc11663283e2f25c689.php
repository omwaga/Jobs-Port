<?php $__env->startSection('content'); ?>
 <div class="container" style="margin-top:5%;">
     	<br>
     	<div class="container">
     	    <div class="row">
     	        <div class="col-md-8">
     	            
     	<div class="card card-body border-light shadow-lg p-3 mb-5 bg-white rounded" align="center">
     	      <h5 style="color:#070A53;"><strong>Selected Industries</strong></h5>  
     	      <ul>
     	          <?php $__currentLoopData = $user_industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	          <li><?php echo e($user_industry->industry->name); ?></li>
     	          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     	      </ul>
             <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php if($user_industries->count() > 0): ?>
             <button class="btn text-white pull-right" style="background-color:#070A53;" data-toggle="modal" data-target="#newindustry">Add Industry</button>
             <?php echo $__env->make('dashboard.add-industrymodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php else: ?>
     	     <form method="post" action="<?php echo e(route('rjobs')); ?>">
     	            <?php echo csrf_field(); ?>
     	    <div class="row">
     	        <div class="col-md-6">
     	            <label>Select Industry</label>
     	            <select data-live-search="true" name="industry" class="form-control" data-live-search-style="startsWith" class="selectpicker">
     	                <option>Select Industry</option>
     	                <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	                <option value="<?php echo e($industry->id); ?>"><?php echo e($industry->name); ?></option>
     	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     	            </select>
     	            
     	        </div>
     	        <div class="col-md-6">
     	           <br>
     	           <button type="submit" class="btn text-white"  style="background-color:#070A53;">Save</button>
    
     	        </div>
     	    </div>
     	  </form>
     	  <?php endif; ?>
     	</div> 
     	        </div>
     	        <div class="col-md-4">
     	       	    <?php echo $__env->make('new.rightnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     	        </div>
     	        </div>
     	    </div>
     	</div>
 </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/dashboard/recommended-jobs.blade.php ENDPATH**/ ?>