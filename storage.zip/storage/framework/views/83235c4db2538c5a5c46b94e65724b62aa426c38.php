<?php $__env->startSection('content'); ?>
<div class="container" style="padding: 5%;">
    <div class="card card-body">
        <div class="row">
            <div class="col-md-12">
       <?php echo Form::open(['action'=>'PagesController@storeprof','method'=>'POST','class'=>'needs-validation','enctype'=>'multipart/form-data']); ?>

            <?php echo e(csrf_field()); ?>

                                        <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <br>
  <fieldset class="border p-2">
    <legend  class="w-auto">Create your Company Profile</legend>
    <div class="row">
        <div class="col-md-6">
              <div class="form-group">
    <label for="exampleFormControlInput1">First Name</label>
    <input type="text" class="form-control border-success <?php if ($errors->has('fname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('fname')); ?>" placeholder="Catherine" style="border-radius: 0px;" name="fname" required>
    <?php if ($errors->has('fname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fname'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  </div>
        </div>
        <div class="col-md-6">
              <div class="form-group">
    <label for="exampleFormControlInput1">Lastname</label>
    <input type="text" class="form-control border-success <?php if ($errors->has('lname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('lname')); ?>" placeholder="catheri" style="border-radius: 0px;" name="lname" required>
     <?php if ($errors->has('lname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lname'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
              <div class="form-group">
    <label for="exampleFormControlInput1">Email address</label>
    <input type="email" class="form-control border-success <?php if ($errors->has('ccemail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ccemail'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Catherine@gmail.com" style="border-radius: 0px;" name="ccemail" autocomplete="ccemail" required>
     <?php if ($errors->has('ccemail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ccemail'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  </div>
        </div>
        <div class="col-md-6">
              <div class="form-group">
    <label for="exampleFormControlInput1">Create your password</label>
    <input type="password" class="form-control border-success <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="catherine@gmail.com" style="border-radius: 0px;" name="password" required>
  </div>
        </div>
    </div>
<div class="row">
        <div class="col-md-6">
              <div class="form-group">
    <label for="exampleFormControlInput1">Phone Number</label>
    <input type="tel" class="form-control border-success <?php if ($errors->has('tel')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tel'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Catherine" style="border-radius: 0px;" name="tel" value="<?php echo e(old('tel')); ?>" required>
    <?php if ($errors->has('tel')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tel'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  </div>
        </div>
        <div class="col-md-6">
              <div class="form-group">
    <label for="exampleFormControlInput1">Address</label>
    <input type="text" class="form-control border-success <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="P.O.BOX kasarani" style="border-radius: 0px;" name="address" value="<?php echo e(old('address')); ?>" required>
     <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
           
        </div>
        <div class="col-md-6 ">
            <button class="btn btn-info float-right btn-block text-white" type="submit" style="border-radius:0px;">Next <i class="fas fa-angle-double-right"></i></button>
        </div>
    </div>
  </fieldset>
                      <?php if(session('status')): ?>
                                  <div class="alert alert-success">
                                  <?php echo e(session('status')); ?>

                                           </div>
                                           <?php endif; ?>
    <?php echo Form::close(); ?>

</div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ires\Documents\GitHub\Jobs-Port\resources\views/new/Employerlogin.blade.php ENDPATH**/ ?>