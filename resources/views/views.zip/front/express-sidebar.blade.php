   
<div class="card card-body border-light shadow-sm p-3 mb-3 bg-white rounded">
  <h5 class="text-center">Job seekers</h5>
  <p>Get started with the Networked Pros Express Recruitment</p>
  <a href="{{route('login')}}" class="btn btn-danger">Get Started</a>
</div> 
<div class="card card-body border-light shadow-sm p-3 mb-3 bg-white rounded"> 
  <h5 class="text-center">Employers</h5>           
  <p>Browse 1000s of Candidates for Free.
  <!-- NetworkedPros makes it easy for quality employers and Candidates to connect, collaborate, and get work done flexibly and securely. --></p>
  <a href="{{route('foremployer')}}" class="btn btn-danger">Get Started</a>
</div>