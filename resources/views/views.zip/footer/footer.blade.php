<footer class="p-5 bg-theme text-small" style="color:#fff;margin-top:0px;">
    <div class="container">
        <div class="row">

            <div class="col-12 col-sm-12 col-md-9">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <h5 style="color: #F4A506">Job Seekers</h5>
                        <ul class="list-unstyled">
                            <li><a href="{{route('alljobs')}}"class="text-white">Browse Latest Jobs Jobs</a></li>
                            <li><a href="{{route('Register')}}" class="text-white">Create Career Profile</a></li>
                            <li><a href="{{route('faqs')}}" class="text-white">FAQs</a></li>
                            <li><a href="/policy" class="text-white">Privacy Policy</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-6">
                        <h5 style="color: #F4A506">Employers</h5>
                        <ul class="list-unstyled">
                            <li><a href="{{route('hirre')}}" class="text-white">Create Account</a></li>
                            <li><a href="{{route('foremployer')}}"class="text-white">Post a Job</a></li>
                        </ul>
                        <p class="text-white">Reach Us through <a href="mailto:careers@thenetworkedpros.com?Subject=POST%20JOB" target="_top " style="color: #F4A506"> careers@thenetworkedpros.com</a> or call +254 706468123</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-3 text-white">
               <div class="col-12 col-sm-10">
                <h5 style="color: #F4A506">Resume Builder</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">CV Design</a></li>
                    <li><a href="#" class="text-white">Cover Letter Design</a></li>
                    <li><a href="#" class="text-white">Work Readiness Program</a></li>
                </ul>
            </div>
        </div>
    </div><hr>
    <div class="col-12 text-center text-white">
        <p class="text-white">©<script>document.write(new Date().getFullYear());</script> The Networked Pros. All Rights Reserved.</p>
    </div>
</div>
</footer>